# Electron
Electron is an open source project for the development of a 2D graphics
circuit simulator.

Project created by Bursuc Eduarda & Zara Mihnea-Tudor, Faculty of Computer Sience, University "Alexandru Ioan Cuza" of Iasi, Romania, 2022